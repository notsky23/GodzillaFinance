package com.example.godzillafinance;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Input_layout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_layout);
    }

}