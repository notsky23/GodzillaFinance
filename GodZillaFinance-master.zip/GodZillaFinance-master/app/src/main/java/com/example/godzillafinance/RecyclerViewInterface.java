package com.example.godzillafinance;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
